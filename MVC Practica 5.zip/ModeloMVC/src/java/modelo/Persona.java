/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author HP
     */
public class Persona {
    private String nombre;
    private String ApellidoP;
    private String ApellidoM;
    private String Correo;
    private String FechaN;
    
    public Persona(String nombre, String ApellidoP, String ApellidoM, String Correo, String FechaN){
           this.nombre = nombre;
           this.ApellidoP = ApellidoP;
           this.ApellidoM = ApellidoM;
           this.Correo= Correo;
           this.FechaN = FechaN;
    }

    public Persona(String nombre, String ApellidoP, String ApellidoM, int fe, String Correo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the ApellidoP
     */
    public String getApellidoP() {
        return ApellidoP;
    }

    /**
     * @param ApellidoP the ApellidoP to set
     */
    public void setApellidoP(String ApellidoP) {
        this.ApellidoP = ApellidoP;
    }

    /**
     * @return the ApellidoM
     */
    public String getApellidoM() {
        return ApellidoM;
    }

    /**
     * @param ApellidoM the ApellidoM to set
     */
    public void setApellidoM(String ApellidoM) {
        this.ApellidoM = ApellidoM;
    }

    /**
     * @return the Correo
     */
    public String getCorreo() {
        return Correo;
    }

    /**
     * @param Correo the Correo to set
     */
    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    /**
     * @return the FechaN
     */
    public String getFechaN() {
        return FechaN;
    }

    /**
     * @param FechaN the FechaN to set
     */
    public void setFechaN(String FechaN) {
        this.FechaN = FechaN;
    }
 
}
           
           
            
