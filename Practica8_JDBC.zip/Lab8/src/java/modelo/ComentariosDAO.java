/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ricardo
 */
public class ComentariosDAO {
    private Connection conexion;
    
    private void abrirConexion() throws SQLException{
        String dbURI = "jdbc:derby://localhost:1527/ComentariosDAO";;
        
        //**
        String username="fcfm";
        String  password="lsti01";  //**
        conexion = DriverManager.getConnection(dbURI,username, password);
    }
    private void cerrarConexion() throws SQLException{
        conexion.close();
    }
   
    public void insertar(ComentariosPOJO coment)throws SQLException{
        try {
            abrirConexion();
            String sql = "insert into COMENTARIOS(NOMBRE,COMENTARIO) values('" + coment.getNombre() + "', '" + coment.getComentario() + "')";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(sql);
            cerrarConexion();
        } catch (SQLException ex) {
            Logger.getLogger(ComentariosDAO.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public ArrayList<ComentariosPOJO> buscar(ComentariosPOJO pojo){
        try {
            abrirConexion();
            String sql = "SELECT * FROM COMENTARIOS WHERE NOMBRE = '" + pojo.getNombre() +"' AND COMENTARIO LIKE '" + pojo.getComentario()+ "'";
            ArrayList<ComentariosPOJO> beans = new ArrayList();
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                String nombre = rs.getString("NOMBRE");
                String comentario = rs.getString("COMENTARIO");
                ComentariosPOJO cpojo = new ComentariosPOJO(nombre, comentario);
                beans.add(cpojo);
            }
            cerrarConexion();
            return beans;
        } catch (SQLException ex) {
            return null;
        }
    }
    
}

