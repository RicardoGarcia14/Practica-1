create Database P1
use P1