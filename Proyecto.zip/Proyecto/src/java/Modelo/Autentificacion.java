/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author dario
 */
public class Autentificacion {
    public static boolean autenticar(String usuario, String password){
        if(usuario.equals("Ricardo")&& password.equals("1234")){
         return true;   
        }else{
            return false;
        }
    }
}
